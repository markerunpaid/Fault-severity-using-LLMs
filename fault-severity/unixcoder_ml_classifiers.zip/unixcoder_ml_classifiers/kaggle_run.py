# kaggle_run.py
"""
All-in-one script for Kaggle execution.
Runs the full pipeline:
    1. Install dependencies
    2. Extract 778-dim UniXcoder features  (GPU accelerated)
    3. Train XGBoost / CatBoost / LightGBM / SVM classifiers
    4. Print comparison table + save results

Run on Kaggle:
    !python kaggle_run.py --checkpoint /kaggle/input/<your-dataset>/best_unixcoder.pt

Or without a checkpoint (uses raw pretrained UniXcoder weights):
    !python kaggle_run.py
"""

import subprocess, sys, os, argparse

# ── Install deps ──────────────────────────────────────────────────────────────
PACKAGES = [
    "xgboost>=2.0",
    "catboost",
    "lightgbm",
    "optuna",
    "scikit-learn",
    "transformers",
    "torch",
    "numpy",
    "pandas",
    "joblib",
    "tqdm",
]

def install_packages():
    print("Installing required packages...")
    for pkg in PACKAGES:
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install", "-q", pkg]
        )
    print("All packages installed.\n")


# ─────────────────────────────────────────────────────────────────────────────
# Parse args first so we can pass them through
# ─────────────────────────────────────────────────────────────────────────────
def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint",   type=str,  default="checkpoints/best_unixcoder.pt")
    parser.add_argument("--dropout",      type=float, default=0.289)
    parser.add_argument("--n_trials",     type=int,   default=20,
                        help="Optuna trials per classifier")
    parser.add_argument("--no_tune",      action="store_true",
                        help="Skip Optuna, use default hyperparameters")
    parser.add_argument("--classifiers",  nargs="+",
                        default=["xgboost", "catboost", "lightgbm", "svm"],
                        choices=["xgboost", "catboost", "lightgbm", "svm"])
    parser.add_argument("--skip_extract", action="store_true",
                        help="Skip extraction if features/ already exists")
    parser.add_argument("--data_dir",     type=str, default="data",
                        help="Directory containing train_final.csv and test_final.csv")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()

    # Make sure src/ is importable
    sys.path.insert(0, "src")

    # ── Kaggle path remapping ─────────────────────────────────────────────────
    # On Kaggle the working dir is /kaggle/working
    # Data is typically at /kaggle/input/<dataset-name>/
    # Adjust data_dir if running on Kaggle
    if os.path.exists("/kaggle"):
        print("Kaggle environment detected.")
        os.makedirs("/kaggle/working/checkpoints", exist_ok=True)
        os.makedirs("/kaggle/working/features",    exist_ok=True)
        os.makedirs("/kaggle/working/results",     exist_ok=True)
        # Change to working dir so relative paths work
        os.chdir("/kaggle/working")

    os.makedirs("checkpoints", exist_ok=True)
    os.makedirs("features",    exist_ok=True)
    os.makedirs("results",     exist_ok=True)

    # ── Step 0: Install ───────────────────────────────────────────────────────
    install_packages()

    # ── Step 1: Feature Extraction ────────────────────────────────────────────
    feature_exists = (
        os.path.exists("features/train_features.npz") and
        os.path.exists("features/test_features.npz")
    )

    if args.skip_extract and feature_exists:
        print("Skipping feature extraction (--skip_extract and features/ found).\n")
    else:
        print("="*60)
        print("STEP 1: Feature Extraction")
        print("="*60)
        extract_cmd = [
            sys.executable, "src/extract_features.py",
            "--checkpoint", args.checkpoint,
            "--dropout",    str(args.dropout),
        ]
        subprocess.check_call(extract_cmd)

    # ── Step 2: Train ML Classifiers ─────────────────────────────────────────
    print("\n" + "="*60)
    print("STEP 2: Train ML Classifiers")
    print("="*60)
    clf_cmd = [
        sys.executable, "src/train_ml_classifiers.py",
        "--classifiers", *args.classifiers,
        "--n_trials",    str(args.n_trials),
    ]
    if args.no_tune:
        clf_cmd.append("--no_tune")
    subprocess.check_call(clf_cmd)

    print("\n" + "="*60)
    print("Pipeline complete. Results saved to results/")
    print("="*60)
