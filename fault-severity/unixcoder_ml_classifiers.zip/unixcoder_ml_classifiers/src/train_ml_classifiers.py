# src/train_ml_classifiers.py
"""
Step 2: Train XGBoost / CatBoost / LightGBM / SVM on top of
        the 778-dim UniXcoder feature vectors.

Each classifier is:
    - Optionally tuned with Optuna (N_TRIALS trials)
    - Trained on train_features.npz
    - Evaluated on test_features.npz
    - Saved to checkpoints/

Usage:
    python src/train_ml_classifiers.py
    python src/train_ml_classifiers.py --classifiers xgboost lightgbm
    python src/train_ml_classifiers.py --no_tune          # skip Optuna, use defaults
    python src/train_ml_classifiers.py --n_trials 30

Results saved to:
    results/ml_classifiers_results.json
    results/ml_classifiers_comparison.csv
"""

import os, sys, json, argparse, warnings
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, f1_score, matthews_corrcoef,
    recall_score, classification_report, roc_auc_score
)
from sklearn.preprocessing import StandardScaler, LabelEncoder
import joblib
import optuna
optuna.logging.set_verbosity(optuna.logging.WARNING)
warnings.filterwarnings("ignore")

# ── Helpers ───────────────────────────────────────────────────────────────────
def geometric_mean(y_true, y_pred):
    r = recall_score(y_true, y_pred, average=None, zero_division=0)
    r = r[r > 0]
    return float(np.prod(r) ** (1.0 / len(r))) if len(r) > 0 else 0.0

def compute_roc_auc(y_true, y_prob):
    try:
        return round(roc_auc_score(y_true, y_prob, multi_class='ovr', average='macro'), 4)
    except Exception:
        return 0.0

def compute_metrics(name, y_true, y_pred, y_prob=None):
    metrics = {
        "model":           name,
        "accuracy":        round(accuracy_score(y_true, y_pred), 4),
        "macro_f1":        round(f1_score(y_true, y_pred, average='macro',    zero_division=0), 4),
        "weighted_f1":     round(f1_score(y_true, y_pred, average='weighted', zero_division=0), 4),
        "mcc":             round(matthews_corrcoef(y_true, y_pred), 4),
        "g_mean":          round(geometric_mean(y_true, y_pred), 4),
    }
    if y_prob is not None:
        metrics["roc_auc_macro"] = compute_roc_auc(y_true, y_prob)

    # Per-class F1
    per_f1 = f1_score(y_true, y_pred, average=None, zero_division=0)
    CLASS_NAMES = ['Critical(0)', 'Major(1)', 'Medium(2)', 'Low(3)']
    metrics["per_class_f1"] = {
        CLASS_NAMES[i]: round(float(per_f1[i]), 4)
        for i in range(min(len(per_f1), 4))
    }
    return metrics

def print_metrics(m):
    print(f"\n  {'─'*52}")
    print(f"  Model        : {m['model']}")
    print(f"  Accuracy     : {m['accuracy']:.4f}")
    print(f"  Macro F1     : {m['macro_f1']:.4f}")
    print(f"  Weighted F1  : {m['weighted_f1']:.4f}")
    print(f"  MCC          : {m['mcc']:.4f}")
    print(f"  G-Mean       : {m['g_mean']:.4f}")
    if "roc_auc_macro" in m:
        print(f"  ROC-AUC(M)   : {m['roc_auc_macro']:.4f}")
    print(f"\n  Per-Class F1:")
    for cls, val in m["per_class_f1"].items():
        print(f"    {cls:<15}: {val:.4f}")


# ── Load features ─────────────────────────────────────────────────────────────
def load_features():
    tr = np.load("features/train_features.npz")
    te = np.load("features/test_features.npz")
    X_train, y_train = tr["X"], tr["y"]
    X_test,  y_test  = te["X"], te["y"]
    print(f"  Train: {X_train.shape}  |  Test: {X_test.shape}")
    print(f"  Feature dim: {X_train.shape[1]}")
    return X_train, y_train, X_test, y_test


# ─────────────────────────────────────────────────────────────────────────────
# XGBoost
# ─────────────────────────────────────────────────────────────────────────────
def train_xgboost(X_train, y_train, X_test, y_test, n_trials=20, tune=True):
    from xgboost import XGBClassifier
    print(f"\n{'='*60}")
    print("XGBoost Classifier")
    print(f"{'='*60}")

    def objective(trial):
        params = {
            "n_estimators":      trial.suggest_int("n_estimators",   100, 800),
            "max_depth":         trial.suggest_int("max_depth",       3,   10),
            "learning_rate":     trial.suggest_float("learning_rate", 0.01, 0.3, log=True),
            "subsample":         trial.suggest_float("subsample",     0.5,  1.0),
            "colsample_bytree":  trial.suggest_float("colsample_bytree", 0.5, 1.0),
            "min_child_weight":  trial.suggest_int("min_child_weight", 1, 10),
            "gamma":             trial.suggest_float("gamma",         0.0,  5.0),
            "reg_alpha":         trial.suggest_float("reg_alpha",     1e-8, 10.0, log=True),
            "reg_lambda":        trial.suggest_float("reg_lambda",    1e-8, 10.0, log=True),
            "use_label_encoder": False,
            "eval_metric":       "mlogloss",
            "objective":         "multi:softmax",
            "num_class":         4,
            "tree_method":       "hist",
            "device":            "cuda" if _cuda_available() else "cpu",
            "verbosity":         0,
            "random_state":      42,
        }
        clf = XGBClassifier(**params)
        clf.fit(X_train, y_train, eval_set=[(X_test, y_test)], verbose=False)
        preds = clf.predict(X_test)
        return f1_score(y_test, preds, average='macro', zero_division=0)

    if tune:
        print(f"  Tuning with Optuna ({n_trials} trials)...")
        study = optuna.create_study(direction="maximize",
                                    sampler=optuna.samplers.TPESampler(seed=42))
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
        best_p = study.best_params
        print(f"  Best Val Macro F1: {study.best_value:.4f}")
        print(f"  Best params: {best_p}")
    else:
        best_p = {
            "n_estimators": 300, "max_depth": 6, "learning_rate": 0.05,
            "subsample": 0.8, "colsample_bytree": 0.8,
        }
        print(f"  Using default params (no tuning).")

    # Final model
    final_params = {
        **best_p,
        "use_label_encoder": False,
        "eval_metric":       "mlogloss",
        "objective":         "multi:softmax",
        "num_class":         4,
        "tree_method":       "hist",
        "device":            "cuda" if _cuda_available() else "cpu",
        "verbosity":         0,
        "random_state":      42,
    }
    clf = XGBClassifier(**final_params)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test)
    y_prob = clf.predict_proba(X_test)

    os.makedirs("checkpoints", exist_ok=True)
    joblib.dump(clf, "checkpoints/xgboost_classifier.joblib")
    print(f"  Saved → checkpoints/xgboost_classifier.joblib")

    m = compute_metrics("XGBoost", y_test, y_pred, y_prob)
    m["best_params"] = best_p
    print_metrics(m)
    print(f"\n{classification_report(y_test, y_pred, target_names=['Critical','Major','Medium','Low'], zero_division=0)}")
    return m


# ─────────────────────────────────────────────────────────────────────────────
# CatBoost
# ─────────────────────────────────────────────────────────────────────────────
def train_catboost(X_train, y_train, X_test, y_test, n_trials=20, tune=True):
    from catboost import CatBoostClassifier
    print(f"\n{'='*60}")
    print("CatBoost Classifier")
    print(f"{'='*60}")

    def objective(trial):
        params = {
            "iterations":         trial.suggest_int("iterations",         100, 800),
            "depth":              trial.suggest_int("depth",              4,   10),
            "learning_rate":      trial.suggest_float("learning_rate",    0.01, 0.3, log=True),
            "l2_leaf_reg":        trial.suggest_float("l2_leaf_reg",      1,   10.0),
            "border_count":       trial.suggest_int("border_count",       32,  255),
            "bagging_temperature": trial.suggest_float("bagging_temperature", 0.0, 1.0),
            "random_strength":    trial.suggest_float("random_strength",  0.0, 10.0),
            "loss_function":      "MultiClass",
            "eval_metric":        "TotalF1",
            "task_type":          "GPU" if _cuda_available() else "CPU",
            "verbose":            False,
            "random_seed":        42,
        }
        clf = CatBoostClassifier(**params)
        clf.fit(X_train, y_train, eval_set=(X_test, y_test), early_stopping_rounds=30)
        preds = clf.predict(X_test).ravel()
        return f1_score(y_test, preds, average='macro', zero_division=0)

    if tune:
        print(f"  Tuning with Optuna ({n_trials} trials)...")
        study = optuna.create_study(direction="maximize",
                                    sampler=optuna.samplers.TPESampler(seed=42))
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
        best_p = study.best_params
        print(f"  Best Val Macro F1: {study.best_value:.4f}")
        print(f"  Best params: {best_p}")
    else:
        best_p = {
            "iterations": 400, "depth": 6, "learning_rate": 0.05,
            "l2_leaf_reg": 3.0,
        }
        print(f"  Using default params (no tuning).")

    final_params = {
        **best_p,
        "loss_function": "MultiClass",
        "eval_metric":   "TotalF1",
        "task_type":     "GPU" if _cuda_available() else "CPU",
        "verbose":       False,
        "random_seed":   42,
    }
    clf = CatBoostClassifier(**final_params)
    clf.fit(X_train, y_train)
    y_pred = clf.predict(X_test).ravel()
    y_prob = clf.predict_proba(X_test)

    joblib.dump(clf, "checkpoints/catboost_classifier.joblib")
    print(f"  Saved → checkpoints/catboost_classifier.joblib")

    m = compute_metrics("CatBoost", y_test, y_pred, y_prob)
    m["best_params"] = best_p
    print_metrics(m)
    print(f"\n{classification_report(y_test, y_pred, target_names=['Critical','Major','Medium','Low'], zero_division=0)}")
    return m


# ─────────────────────────────────────────────────────────────────────────────
# LightGBM
# ─────────────────────────────────────────────────────────────────────────────
def train_lightgbm(X_train, y_train, X_test, y_test, n_trials=20, tune=True):
    import lightgbm as lgb
    print(f"\n{'='*60}")
    print("LightGBM Classifier")
    print(f"{'='*60}")

    def objective(trial):
        params = {
            "n_estimators":       trial.suggest_int("n_estimators",      100, 800),
            "num_leaves":         trial.suggest_int("num_leaves",         20,  300),
            "max_depth":          trial.suggest_int("max_depth",          -1,  15),
            "learning_rate":      trial.suggest_float("learning_rate",    0.01, 0.3, log=True),
            "min_child_samples":  trial.suggest_int("min_child_samples",  5,   100),
            "subsample":          trial.suggest_float("subsample",        0.5,  1.0),
            "colsample_bytree":   trial.suggest_float("colsample_bytree", 0.5,  1.0),
            "reg_alpha":          trial.suggest_float("reg_alpha",        1e-8, 10.0, log=True),
            "reg_lambda":         trial.suggest_float("reg_lambda",       1e-8, 10.0, log=True),
            "objective":          "multiclass",
            "num_class":          4,
            "metric":             "multi_logloss",
            "device_type":        "gpu" if _cuda_available() else "cpu",
            "verbosity":          -1,
            "random_state":       42,
        }
        clf = lgb.LGBMClassifier(**params)
        clf.fit(X_train, y_train,
                eval_set=[(X_test, y_test)],
                callbacks=[lgb.early_stopping(30, verbose=False),
                           lgb.log_evaluation(-1)])
        preds = clf.predict(X_test)
        return f1_score(y_test, preds, average='macro', zero_division=0)

    if tune:
        print(f"  Tuning with Optuna ({n_trials} trials)...")
        study = optuna.create_study(direction="maximize",
                                    sampler=optuna.samplers.TPESampler(seed=42))
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
        best_p = study.best_params
        print(f"  Best Val Macro F1: {study.best_value:.4f}")
        print(f"  Best params: {best_p}")
    else:
        best_p = {
            "n_estimators": 300, "num_leaves": 63, "learning_rate": 0.05,
            "subsample": 0.8, "colsample_bytree": 0.8,
        }
        print(f"  Using default params (no tuning).")

    import lightgbm as lgb
    final_params = {
        **best_p,
        "objective":     "multiclass",
        "num_class":     4,
        "metric":        "multi_logloss",
        "device_type":   "gpu" if _cuda_available() else "cpu",
        "verbosity":     -1,
        "random_state":  42,
    }
    clf = lgb.LGBMClassifier(**final_params)
    clf.fit(X_train, y_train, callbacks=[lgb.log_evaluation(-1)])
    y_pred = clf.predict(X_test)
    y_prob = clf.predict_proba(X_test)

    joblib.dump(clf, "checkpoints/lightgbm_classifier.joblib")
    print(f"  Saved → checkpoints/lightgbm_classifier.joblib")

    m = compute_metrics("LightGBM", y_test, y_pred, y_prob)
    m["best_params"] = best_p
    print_metrics(m)
    print(f"\n{classification_report(y_test, y_pred, target_names=['Critical','Major','Medium','Low'], zero_division=0)}")
    return m


# ─────────────────────────────────────────────────────────────────────────────
# SVM
# ─────────────────────────────────────────────────────────────────────────────
def train_svm(X_train, y_train, X_test, y_test, n_trials=20, tune=True):
    from sklearn.svm import SVC
    from sklearn.pipeline import Pipeline

    print(f"\n{'='*60}")
    print("SVM Classifier  (RBF kernel, scaled features)")
    print(f"{'='*60}")

    # SVM needs scaled features
    scaler  = StandardScaler()
    Xtr_sc  = scaler.fit_transform(X_train)
    Xte_sc  = scaler.transform(X_test)

    def objective(trial):
        kernel = trial.suggest_categorical("kernel", ["rbf", "poly"])
        params = {
            "C":               trial.suggest_float("C",     0.01,  100.0, log=True),
            "gamma":           trial.suggest_categorical("gamma", ["scale", "auto"]),
            "kernel":          kernel,
            "decision_function_shape": "ovr",
            "probability":     True,
            "class_weight":    "balanced",
            "random_state":    42,
            "max_iter":        2000,
        }
        if kernel == "poly":
            params["degree"] = trial.suggest_int("degree", 2, 4)

        clf = SVC(**params)
        clf.fit(Xtr_sc, y_train)
        preds = clf.predict(Xte_sc)
        return f1_score(y_test, preds, average='macro', zero_division=0)

    if tune:
        print(f"  Tuning with Optuna ({n_trials} trials)...")
        study = optuna.create_study(direction="maximize",
                                    sampler=optuna.samplers.TPESampler(seed=42))
        study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
        best_p = study.best_params
        print(f"  Best Val Macro F1: {study.best_value:.4f}")
        print(f"  Best params: {best_p}")
    else:
        best_p = {"C": 1.0, "gamma": "scale", "kernel": "rbf"}
        print(f"  Using default params (no tuning).")

    clf = SVC(
        **best_p,
        decision_function_shape="ovr",
        probability=True,
        class_weight="balanced",
        random_state=42,
        max_iter=5000,
    )
    clf.fit(Xtr_sc, y_train)
    y_pred = clf.predict(Xte_sc)
    y_prob = clf.predict_proba(Xte_sc)

    # Save scaler + clf together
    pipeline = {"scaler": scaler, "clf": clf}
    joblib.dump(pipeline, "checkpoints/svm_classifier.joblib")
    print(f"  Saved → checkpoints/svm_classifier.joblib")

    m = compute_metrics("SVM", y_test, y_pred, y_prob)
    m["best_params"] = best_p
    print_metrics(m)
    print(f"\n{classification_report(y_test, y_pred, target_names=['Critical','Major','Medium','Low'], zero_division=0)}")
    return m


# ─────────────────────────────────────────────────────────────────────────────
# Comparison table
# ─────────────────────────────────────────────────────────────────────────────
def print_comparison(all_results):
    models = list(all_results.keys())
    COL    = 14
    METRICS = [
        ("Accuracy",    "accuracy"),
        ("Macro F1",    "macro_f1"),
        ("Weighted F1", "weighted_f1"),
        ("MCC",         "mcc"),
        ("G-Mean",      "g_mean"),
        ("ROC-AUC(M)",  "roc_auc_macro"),
    ]

    print(f"\n\n{'='*75}")
    print("FINAL COMPARISON — UniXcoder + ML Classifiers")
    print(f"{'='*75}")

    header = f"{'Metric':<20}" + "".join(f"{m:>{COL}}" for m in models)
    print(header)
    print("-"*75)
    for label, key in METRICS:
        row = f"{label:<20}"
        for m in models:
            val = all_results[m].get(key, 0.0)
            row += f"{val:>{COL}.4f}"
        print(row)

    print(f"\n{'Per-Class F1':}")
    print(f"{'='*75}")
    print(f"{'Class':<20}" + "".join(f"{m:>{COL}}" for m in models))
    print("-"*75)
    classes = ['Critical(0)', 'Major(1)', 'Medium(2)', 'Low(3)']
    for cls in classes:
        row = f"{cls:<20}"
        for m in models:
            val = all_results[m].get("per_class_f1", {}).get(cls, 0.0)
            row += f"{val:>{COL}.4f}"
        print(row)

    print(f"\n{'='*75}")
    best = max(all_results, key=lambda m: all_results[m].get("macro_f1", 0))
    print(f"  BEST MODEL : {best}  |  Macro F1 = {all_results[best]['macro_f1']:.4f}")
    print(f"{'='*75}")


def _cuda_available():
    import torch
    return torch.cuda.is_available()


# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────
TRAINER_MAP = {
    "xgboost":  train_xgboost,
    "catboost": train_catboost,
    "lightgbm": train_lightgbm,
    "svm":      train_svm,
}

def main(args):
    print(f"\n{'='*60}")
    print("UniXcoder + ML Classifiers")
    print(f"{'='*60}")

    if not os.path.exists("features/train_features.npz"):
        print("ERROR: features/train_features.npz not found.")
        print("Run extract_features.py first.")
        sys.exit(1)

    X_train, y_train, X_test, y_test = load_features()

    all_results = {}
    for clf_name in args.classifiers:
        fn = TRAINER_MAP[clf_name]
        result = fn(X_train, y_train, X_test, y_test,
                    n_trials=args.n_trials, tune=not args.no_tune)
        all_results[clf_name] = result

    print_comparison(all_results)

    # ── Save results ──────────────────────────────────────────────────────────
    os.makedirs("results", exist_ok=True)
    with open("results/ml_classifiers_results.json", "w") as f:
        json.dump(all_results, f, indent=2)
    print(f"\n  Saved → results/ml_classifiers_results.json")

    # CSV summary
    rows = []
    for name, m in all_results.items():
        row = {"model": name, **{k: v for k, v in m.items()
                                 if k not in ("best_params", "per_class_f1", "model")}}
        row.update({f"f1_{c.replace('(','').replace(')','').lower()}": v
                    for c, v in m.get("per_class_f1", {}).items()})
        rows.append(row)
    pd.DataFrame(rows).to_csv("results/ml_classifiers_comparison.csv", index=False)
    print(f"  Saved → results/ml_classifiers_comparison.csv")

    print(f"\n✅ All done!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--classifiers", nargs="+",
        default=["xgboost", "catboost", "lightgbm", "svm"],
        choices=["xgboost", "catboost", "lightgbm", "svm"],
        help="Which classifiers to train"
    )
    parser.add_argument(
        "--n_trials", type=int, default=20,
        help="Number of Optuna trials per classifier"
    )
    parser.add_argument(
        "--no_tune", action="store_true",
        help="Skip Optuna tuning, use sensible defaults"
    )
    main(parser.parse_args())
