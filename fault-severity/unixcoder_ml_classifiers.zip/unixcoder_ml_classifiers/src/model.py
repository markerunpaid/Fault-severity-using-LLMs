# src/model.py

import torch
import torch.nn as nn
from transformers import AutoModel, T5EncoderModel


class ConcatClsModel(nn.Module):

    def __init__(
        self,
        model_name:   str   = "microsoft/unixcoder-base",
        num_metrics:  int   = 10,
        num_classes:  int   = 4,
        dropout_prob: float = 0.1,
    ):
        super(ConcatClsModel, self).__init__()
        self.model_name = model_name

        if "codet5p-220m" in model_name.lower():
            self.encoder   = T5EncoderModel.from_pretrained(model_name)
            hidden_size    = self.encoder.config.d_model
            self.pool_type = "mean"

        elif "codet5p-110m-embedding" in model_name.lower():
            self.encoder   = T5EncoderModel.from_pretrained(
                model_name,
                trust_remote_code       = True,
                ignore_mismatched_sizes = True,
            )
            hidden_size    = self.encoder.config.d_model
            self.pool_type = "mean"

        else:
            # CodeBERT, GraphCodeBERT, UniXcoder — all RoBERTa-style
            self.encoder   = AutoModel.from_pretrained(model_name)
            hidden_size    = self.encoder.config.hidden_size
            self.pool_type = "cls"

        self.dropout    = nn.Dropout(p=dropout_prob)
        # NOTE: For feature extraction we do NOT include the classifier head.
        # The classifier is only here for compatibility if loading a full checkpoint.
        self.classifier = nn.Linear(hidden_size + num_metrics, num_classes)

        print(f"  Encoder : {model_name}")
        print(f"  Hidden  : {hidden_size}  |  Pooling: {self.pool_type}")
        print(f"  Classes : {num_classes}  |  Metrics: {num_metrics}")

    def forward(
        self,
        input_ids:      torch.Tensor,
        attention_mask: torch.Tensor,
        metrics:        torch.Tensor,
    ):
        outputs = self.encoder(
            input_ids      = input_ids,
            attention_mask = attention_mask,
        )

        if self.pool_type == "cls":
            embedding = outputs.last_hidden_state[:, 0, :]
        else:
            token_emb = outputs.last_hidden_state
            mask_exp  = attention_mask.unsqueeze(-1).float()
            sum_emb   = torch.sum(token_emb * mask_exp, dim=1)
            sum_mask  = torch.clamp(mask_exp.sum(dim=1), min=1e-9)
            embedding = sum_emb / sum_mask

        combined = torch.cat([embedding, metrics], dim=1)
        combined = self.dropout(combined)
        logits   = self.classifier(combined)

        return logits

    def get_features(
        self,
        input_ids:      torch.Tensor,
        attention_mask: torch.Tensor,
        metrics:        torch.Tensor,
    ):
        """
        Returns the 778-dim feature vector:
            768 (UniXcoder CLS) + 10 (software metrics)
        Without applying dropout or the classifier head.
        """
        outputs = self.encoder(
            input_ids      = input_ids,
            attention_mask = attention_mask,
        )

        if self.pool_type == "cls":
            embedding = outputs.last_hidden_state[:, 0, :]
        else:
            token_emb = outputs.last_hidden_state
            mask_exp  = attention_mask.unsqueeze(-1).float()
            sum_emb   = torch.sum(token_emb * mask_exp, dim=1)
            sum_mask  = torch.clamp(mask_exp.sum(dim=1), min=1e-9)
            embedding = sum_emb / sum_mask

        combined = torch.cat([embedding, metrics], dim=1)
        return combined
