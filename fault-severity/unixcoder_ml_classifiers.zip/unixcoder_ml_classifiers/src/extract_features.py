# src/extract_features.py
"""
Step 1: Extract 778-dimensional feature vectors from UniXcoder.
    - 768 dims from UniXcoder CLS token (RoBERTa-style)
    - 10 dims from software metrics
    
Saves:
    features/train_features.npz  — X_train, y_train
    features/test_features.npz   — X_test,  y_test

Usage:
    python src/extract_features.py \
        --checkpoint checkpoints/best_unixcoder.pt \
        --dropout 0.289
"""

import os, sys, argparse
import torch
import numpy as np
import pandas as pd
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
from tqdm import tqdm

sys.path.insert(0, "src")
from model import ConcatClsModel
from dataset import BugSeverityDataset

MODEL_NAME  = "microsoft/unixcoder-base"
MAX_LENGTH  = 256
BATCH_SIZE  = 16
NUM_WORKERS = 0


def extract_features(model, loader, device):
    """
    Run the encoder + metric concat (no dropout, no classifier)
    and return (features [N, 778], labels [N]).
    """
    model.eval()
    all_feats, all_labels = [], []

    with torch.no_grad():
        for batch in tqdm(loader, desc="  Extracting", leave=False):
            input_ids      = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            metrics        = batch['metrics'].to(device)
            labels         = batch['label']

            feats = model.get_features(input_ids, attention_mask, metrics)

            all_feats.append(feats.cpu().numpy())
            all_labels.append(labels.numpy())

    X = np.vstack(all_feats)      # [N, 778]
    y = np.concatenate(all_labels) # [N]
    return X, y


def main(args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n{'='*60}")
    print(f"UniXcoder Feature Extractor")
    print(f"{'='*60}")
    print(f"  Device     : {device}")
    if torch.cuda.is_available():
        print(f"  GPU        : {torch.cuda.get_device_name(0)}")
    print(f"  Checkpoint : {args.checkpoint}")
    print(f"  Dropout    : {args.dropout}")

    # ── Load data ─────────────────────────────────────────────────────────────
    train_df = pd.read_csv("data/train_final.csv")
    test_df  = pd.read_csv("data/test_final.csv")
    print(f"\n  Train: {len(train_df)} samples | Test: {len(test_df)} samples")

    # ── Load tokenizer ────────────────────────────────────────────────────────
    print(f"\n  Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)

    train_loader = DataLoader(
        BugSeverityDataset(train_df, tokenizer, MAX_LENGTH),
        batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS,
    )
    test_loader = DataLoader(
        BugSeverityDataset(test_df, tokenizer, MAX_LENGTH),
        batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS,
    )

    # ── Load UniXcoder ────────────────────────────────────────────────────────
    print(f"\n  Loading UniXcoder model...")
    model = ConcatClsModel(
        model_name   = MODEL_NAME,
        dropout_prob = args.dropout,
    ).to(device)

    if args.checkpoint and os.path.exists(args.checkpoint):
        print(f"  Loading weights from {args.checkpoint}")
        state = torch.load(args.checkpoint, map_location=device)
        model.load_state_dict(state)
        print(f"  ✅ Checkpoint loaded.")
    else:
        print(f"  ⚠️  No checkpoint found at '{args.checkpoint}'.")
        print(f"      Proceeding with pretrained UniXcoder weights (no fine-tuning).")
        print(f"      For best results, provide a fine-tuned checkpoint.")

    # ── Extract ───────────────────────────────────────────────────────────────
    print(f"\n  Extracting train features...")
    X_train, y_train = extract_features(model, train_loader, device)

    print(f"  Extracting test features...")
    X_test, y_test = extract_features(model, test_loader, device)

    print(f"\n  Train features shape : {X_train.shape}")
    print(f"  Test features shape  : {X_test.shape}")
    print(f"  Feature dim          : {X_train.shape[1]} (768 CLS + 10 metrics)")

    # ── Save ──────────────────────────────────────────────────────────────────
    os.makedirs("features", exist_ok=True)
    np.savez_compressed("features/train_features.npz", X=X_train, y=y_train)
    np.savez_compressed("features/test_features.npz",  X=X_test,  y=y_test)

    print(f"\n  Saved → features/train_features.npz")
    print(f"  Saved → features/test_features.npz")
    print(f"\n  ✅ Feature extraction complete!")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Extract 778-dim features from UniXcoder"
    )
    parser.add_argument(
        "--checkpoint",
        type=str,
        default="checkpoints/best_unixcoder.pt",
        help="Path to fine-tuned UniXcoder checkpoint (.pt)"
    )
    parser.add_argument(
        "--dropout",
        type=float,
        default=0.289,
        help="Dropout used when the model was trained"
    )
    main(parser.parse_args())
