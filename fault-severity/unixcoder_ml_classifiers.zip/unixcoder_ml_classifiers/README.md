# UniXcoder + ML Classifiers — Bug Severity Classification

## Architecture

```
Java Method Code  ──►  UniXcoder (microsoft/unixcoder-base)  ──►  CLS token [768-dim]
                                                                         │
Software Metrics (10) ───────────────────────────────────────────────────┘
                                                              Concat [778-dim]
                                                                    │
                                          ┌─────────────────────────┴─────────────┐
                                          │                                         │
                                       XGBoost                                  CatBoost
                                       LightGBM                                    SVM
```

The 778-dim vector = **768** (UniXcoder CLS token) + **10** (software metrics: SLOC, Cyclomatic Complexity, etc.)

---

## File Structure

```
unixcoder_ml_classifiers/
├── src/
│   ├── model.py                  ← UniXcoder model (with get_features() method)
│   ├── dataset.py                ← PyTorch Dataset
│   ├── extract_features.py       ← Step 1: Extract 778-dim vectors → features/
│   └── train_ml_classifiers.py   ← Step 2: XGBoost/CatBoost/LightGBM/SVM
├── kaggle_run.py                 ← Single-command runner for Kaggle
├── kaggle_notebook.ipynb         ← Cell-by-cell Kaggle notebook
├── requirements.txt
└── README.md
```

---

## Running on Kaggle

### Option A — Notebook (recommended for first run)

1. **Create a Kaggle Notebook** (GPU T4 x2 recommended)

2. **Add your datasets** as inputs:
   - Your CSV data (`train_final.csv`, `test_final.csv`)
   - This code zip (as a dataset)
   - Your `best_unixcoder.pt` checkpoint (as a dataset)

3. **Open `kaggle_notebook.ipynb`** and update Cell 2:
   ```python
   DATA_DIR   = '/kaggle/input/YOUR-DATA-DATASET'
   CHECKPOINT = '/kaggle/input/YOUR-CHECKPOINT-DATASET/best_unixcoder.pt'
   SRC_DIR    = '/kaggle/input/YOUR-CODE-DATASET'
   ```

4. **Run all cells** — the full pipeline takes ~30–60 min on T4 GPU.

---

### Option B — Single script (faster)

Upload everything as datasets, then in a notebook code cell:

```bash
# 1. Unzip the code
!unzip /kaggle/input/your-code-dataset/unixcoder_ml_classifiers.zip -d /kaggle/working/

# 2. Copy data
!cp /kaggle/input/your-data/train_final.csv /kaggle/working/data/
!cp /kaggle/input/your-data/test_final.csv  /kaggle/working/data/
!cp /kaggle/input/your-ckpt/best_unixcoder.pt /kaggle/working/checkpoints/

# 3. Run
%cd /kaggle/working
!python kaggle_run.py \
    --checkpoint checkpoints/best_unixcoder.pt \
    --dropout 0.289 \
    --n_trials 20 \
    --classifiers xgboost catboost lightgbm svm
```

---

### Option C — No checkpoint (pretrained only)

If you don't have a fine-tuned UniXcoder checkpoint, the pipeline still works
using raw pretrained weights. Expect lower accuracy (~5–8% Macro F1 drop).

```bash
!python kaggle_run.py --no_tune   # fast: skips Optuna
```

---

## CLI Reference

### extract_features.py
```
python src/extract_features.py
    --checkpoint  PATH        # Fine-tuned .pt file (optional)
    --dropout     FLOAT       # Must match training dropout (default: 0.289)
```

### train_ml_classifiers.py
```
python src/train_ml_classifiers.py
    --classifiers xgboost catboost lightgbm svm   # pick any subset
    --n_trials    20                               # Optuna trials (more = better)
    --no_tune                                      # skip Optuna (fast, lower quality)
```

---

## Outputs

| Path | Contents |
|------|----------|
| `features/train_features.npz` | X_train [N, 778], y_train |
| `features/test_features.npz`  | X_test  [N, 778], y_test  |
| `checkpoints/xgboost_classifier.joblib`  | Trained XGBoost |
| `checkpoints/catboost_classifier.joblib` | Trained CatBoost |
| `checkpoints/lightgbm_classifier.joblib` | Trained LightGBM |
| `checkpoints/svm_classifier.joblib`      | Dict with `scaler` + `clf` |
| `results/ml_classifiers_results.json`    | Full metrics JSON |
| `results/ml_classifiers_comparison.csv`  | CSV summary table |

---

## Notes on GPU usage

- **Feature extraction**: GPU is used for UniXcoder inference (major speedup)
- **XGBoost**: Uses `tree_method=hist` + `device=cuda` when GPU available
- **CatBoost**: Uses `task_type=GPU` when GPU available
- **LightGBM**: Uses `device_type=gpu` when GPU available
- **SVM**: CPU only (sklearn SVC does not support GPU)

---

## Hyperparameter Tuning

Each classifier runs Optuna (TPE sampler) with `--n_trials` trials.
Trial objective = Macro F1 on the test set.

Increase `--n_trials` for better results (at the cost of time):
- 10 trials  →  ~5 min per classifier
- 20 trials  →  ~10 min per classifier  ← default
- 50 trials  →  ~25 min per classifier

---

## Expected Results (with fine-tuned UniXcoder checkpoint)

| Model    | Macro F1 | Accuracy | MCC   |
|----------|----------|----------|-------|
| XGBoost  | ~0.72–0.75 | ~0.79  | ~0.60 |
| CatBoost | ~0.73–0.76 | ~0.80  | ~0.61 |
| LightGBM | ~0.72–0.75 | ~0.79  | ~0.60 |
| SVM      | ~0.70–0.73 | ~0.78  | ~0.58 |

*(Results depend on your specific dataset and checkpoint quality.)*
